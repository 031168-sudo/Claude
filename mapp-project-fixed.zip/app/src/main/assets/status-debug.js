// Временный диагностический модуль для экрана "Статус".
// Хранит последние сообщения и выводит их в любую видимую .status-debug-panel на странице.
// Ничего не делает, если панели нет - безопасен для остальных экранов.
(function () {
    window.__statusDebugLog = window.__statusDebugLog || [];

    function safeStringify(data) {
        if (data === undefined) return "";
        try {
            return " " + JSON.stringify(data);
        } catch (e) {
            return " " + String(data);
        }
    }

    function refreshPanels() {
        var panels = document.getElementsByClassName("status-debug-panel");
        if (!panels.length) return;
        var html = window.__statusDebugLog
            .slice()
            .reverse()
            .map(function (line) {
                return line.replace(/&/g, "&amp;").replace(/</g, "&lt;");
            })
            .join("<br>");
        for (var i = 0; i < panels.length; i++) {
            panels[i].innerHTML = html;
        }
    }

    window.pushStatusDebug = function (msg, data) {
        try {
            var ts = new Date().toLocaleTimeString();
            var line = ts + " | " + msg + safeStringify(data);
            window.__statusDebugLog.push(line);
            if (window.__statusDebugLog.length > 80) window.__statusDebugLog.shift();
            refreshPanels();
        } catch (e) {
            // диагностика не должна ломать основной экран
        }
    };

    // если панель появится позже (например при открытии экрана) - подхватит уже накопленную историю
    window.__refreshStatusDebugPanels = refreshPanels;
})();
